#include "tcpserver.h"
#include <fstream>
#include <iostream>
#include <QDir>

TcpServer::TcpServer(QObject *parent, QString path) :
  QTcpServer(parent),
  path(path),
  nrConnections(0)
{

}

bool TcpServer::openServer(quint16 port)
{
    connect(this, SIGNAL(newConnection()), this, SLOT(newConnection()));
    if(!this->listen(QHostAddress::Any, port)) {
        qDebug() << "Server could not start";
        return false;
    } else {
        qDebug() << "Server started";
        return true;
    }
}


void TcpServer::newConnection()
{
    socket = this->nextPendingConnection();
    connect(this->getSocket(), SIGNAL(readyRead()), this, SLOT(getKey()));
    qDebug() << "New connection";
}

void TcpServer::getKey() {
    QString message = readTcp();
    bool ok;
    int size = message.toInt(&ok);
    if(ok) {
        qDebug() << "Size read sucessfully";
    } else {
        qDebug() << "Failed to read the string";
    }

    QFile f(path);
    QString key;
    if(f.open(QIODevice::ReadWrite | QIODevice::Text))
    {
       QString line;
       QTextStream t(&f);
       line = t.readLine();
       f.resize(0);
       t << line.right(line.length() - size);
       f.close();
       key = line.left(size);
    }

    /*
    std::fstream f(QDir::homePath().toLocal8Bit() + "/STPC/QRNG/keys.txt");
    std::string line;
    std::getline(f, line);
    QString key = QString::fromStdString(line).left(size);
    f.close();

    std::fstream r(QDir::homePath().toLocal8Bit() + "/STPC/QRNG/keys.txt", std::ofstream::out | std::ofstream::trunc);
    r.write(line.substr(size).c_str(), line.length() - size);
    r.close();
    */

    qDebug() << key;
    writeTcp(key.toLocal8Bit().data());

    qDebug() << "Key sent!";
    socket->close();
}

void TcpServer::writeTcp(char* message) {
    socket->write(message, sizeof(message) + 1);
    socket->flush();
}

QString TcpServer::readTcp() {
    QString message = socket->readAll();
    return message;
}

void TcpServer::closeServer() {
    qDebug() << "Closing Server";
    socket->close();
    this->close();
}

QTcpSocket* TcpServer::getSocket()
{
    return socket;
}
