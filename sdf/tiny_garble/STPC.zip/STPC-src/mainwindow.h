#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include "stcpwindow.h"
#include "configdialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void choice_clicked(QString);

    void on_tinyGarbleDir_clicked();

    void on_functionsDir_clicked();

    void on_functionsLoc_textChanged(const QString &arg1);

    void on_tinyGarbleLoc_textChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;
    STCPWindow *stcp;
    ConfigDialog *networkDialogAlice;
    ConfigDialog *networkDialogBob;

    bool tgWarning;
    bool fWarning;
};

#endif // MAINWINDOW_H
