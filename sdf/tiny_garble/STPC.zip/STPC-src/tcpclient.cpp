#include "tcpclient.h"

TcpClient::TcpClient(QObject *parent) : QObject(parent),
    connected(false)
{

}

bool TcpClient::connect(QString ip, quint16 port)
{
    socket = new QTcpSocket(this);
    socket->connectToHost(ip, port);
    if(socket->waitForConnected(1000)) {
        qDebug() << "Connected to " + ip + ":" + port;
        connected = true;
        return true;
    } else {
        qDebug() << "Could not connect to host!";
        return false;
    }
}

void TcpClient::disconnect()
{
    if(connected) {
        qDebug() << "Closing Client Socket";
        socket->close();
    }
}

QTcpSocket* TcpClient::getSocket()
{
    return socket;
}
