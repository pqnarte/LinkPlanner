#include "networkconfig.h"
#include "ui_networkconfig.h"

networkConfig::networkConfig(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::networkConfig)
{
    ui->setupUi(this);
    int width = 400;
    int height = 240;
    setFixedSize(width, height);
    connect(ui->buttonBox_2, SIGNAL(accepted()), this, SLOT(accept()));
    connect(ui->buttonBox_2, SIGNAL(rejected()), this, SLOT(reject()));
}

networkConfig::~networkConfig()
{
    delete ui;
}
