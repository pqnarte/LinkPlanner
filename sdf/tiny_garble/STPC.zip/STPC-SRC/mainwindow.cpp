#include "mainwindow.h"
#include "networkconfig.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QSignalMapper>
#include <QRegExpValidator>
#include <QDir>
#include <QFileDialog>
#include <QInputDialog>
#include <QScreen>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    tgWarning = false;
    fWarning = false;

    setWindowTitle("Secure Two-Party Computation");

    int width = 420;
    int height = 230;
    setFixedSize(width, height);

    QScreen *screen = QGuiApplication::primaryScreen();
    QRect  screenGeometry = screen->geometry();
    int screenWidth = screenGeometry.width();
    int screenHeight = screenGeometry.height();

    move((screenWidth - 400) / 2, (screenHeight - 200) / 2);

    QSignalMapper* signalMapper = new QSignalMapper(this);

    connect(ui->alice_button, SIGNAL(clicked()), signalMapper, SLOT(map()));
    signalMapper->setMapping(ui->alice_button, "Alice");
    connect(ui->bob_button, SIGNAL(clicked()), signalMapper, SLOT(map()));
    signalMapper->setMapping(ui->bob_button, "Bob");

    connect(signalMapper, SIGNAL(mapped(QString)), this, SLOT(choice_clicked(QString)));

    char line[500];
    std::FILE *script = popen("locate -l 1 -r TinyGarble$", "r");
    while (fgets(line, sizeof(line), script) != NULL) {}
    pclose(script);
    QString dir = line;
    if(dir.contains("TinyGarble")) {
        ui->tinyGarbleLoc->setText(dir.left(dir.length() - 1));
        on_tinyGarbleLoc_textChanged(ui->tinyGarbleLoc->text());
    }

    networkDialog = new ConfigDialog(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::choice_clicked(QString host)
{

    bool run = true;
    if(tgWarning || ui->tinyGarbleLoc->text() == "") {
        ui->tgWarning->setText("Select a valid path to TinyGarble's directory!");
        run = false;
    }
    if(fWarning || ui->functionsLoc->text() == "") {
        ui->fWarning->setText("Select a valid path to the 'moda.scd' file!");
        run = false;
    }

    if(run) {
        if(networkDialog->execute(host) == QDialog::Accepted) {
            hide();
            stcp = new STCPWindow(nullptr, host, this->pos(), ui->tinyGarbleLoc->text(), ui->functionsLoc->text(), host == "Alice" ? "127.0.0.1" : networkDialog->getTgIp(), networkDialog->getTgPort(), networkDialog->getKeyIp(), networkDialog->getKeyPort());
            stcp->show();
        }
    }

}

void MainWindow::on_tinyGarbleDir_clicked()
{
    this->setStyleSheet("background-color: rgb(62, 104, 135);");
    QString dir = (QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                 QDir::homePath(),
                                                 QFileDialog::ShowDirsOnly
                                                 | QFileDialog::DontResolveSymlinks));
    this->setStyleSheet("background-color: rgb(160,160,160);");
    if(dir != "")
        ui->tinyGarbleLoc->setText(dir);
}

void MainWindow::on_functionsDir_clicked()
{

    this->setStyleSheet("background-color: rgb(62, 104, 135);");
    QString dir = (QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                 QDir::homePath(),
                                                 QFileDialog::ShowDirsOnly
                                                 | QFileDialog::DontResolveSymlinks));
    this->setStyleSheet("background-color: rgb(160,160,160);");
    if(dir != "")
        ui->functionsLoc->setText(dir);
}

void MainWindow::on_tinyGarbleLoc_textChanged(const QString &arg1)
{
    QFile file(arg1 + "/bin/garbled_circuit/TinyGarble");
    if(!file.open(QIODevice::ReadOnly)) {
        tgWarning = true;
        ui->tgWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->tgWarning->setText("The selected folder doesn't contain TinyGarble's executable.");
    } else {
        tgWarning = false;
        ui->tgWarning->setStyleSheet("color: rgb(32, 74, 135);");
        ui->tgWarning->setText("TinyGarble executable found!");
    }
    file.close();
}

void MainWindow::on_functionsLoc_textChanged(const QString &arg1)
{
    QFile file(arg1 + "/moda.scd");
    if(!file.open(QIODevice::ReadOnly)) {
        fWarning = true;
        ui->fWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->fWarning->setText("The selected folder doesn't have the moda '.scd' file in it!");
    } else {
        fWarning = false;
        ui->fWarning->setStyleSheet("color: rgb(32, 74, 135);");
        ui->fWarning->setText("Moda.scd file found!");
    }
    file.close();
}
