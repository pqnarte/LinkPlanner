﻿#include "stcpwindow.h"
#include "ui_stcpwindow.h"

#include <QDebug>
#include <QSignalMapper>
#include <QRegExpValidator>
#include <QDir>
#include <QFile>
#include <QMessageBox>
#include <QTimer>
#include <QTime>

using namespace std;

void delay(int n)
{
    QTime dieTime= QTime::currentTime().addMSecs(n);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

STCPWindow::STCPWindow(QWidget *parent, QString h, QPoint pos, QString tg, QString f, QString tgIp, QString tgPort, QString keyIp, QString keyPort) :
    QMainWindow(parent),
    ui(new Ui::STCPWindow),
    host(h),
    fDir(f),
    tgDir(tg),
    tgIp(tgIp),
    tgPort(tgPort),
    keyIp(keyIp),
    keyPort(keyPort),
    points("")
{
    ui->setupUi(this);

    qDebug() << tgIp;

    state = OFF;

    setWindowTitle("Secure Two-Party Computation");
    setFixedSize(456, 325);
    move(pos);

    ui->hostLabel->setText(host);

    QRegExp rexeg("^[0-9]{0,4}");
    QRegExpValidator *validator = new QRegExpValidator(rexeg);
    ui->input0->setValidator(validator);
    ui->input1->setValidator(validator);

    ui->socketLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
    if(host == "Alice") {
        server = new TcpServer();
        if(!server->openServer(quint16(tgPort.toInt() + 1))) {
            ui->socketLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
            ui->socketLabel->setText("Could not start the server!");
        } else {
            keyClient = new TcpClient();
            connect(server, SIGNAL(newConnection()), this, SLOT(connectClient()));
            ui->socketLabel->setText("Waiting for Bob to connect!");
        }

    } else {
        client = new TcpClient();
        timer = new QTimer(this);
        connect(timer, SIGNAL(timeout()), this, SLOT(connectClient()));
        connectClient();
        ui->socketLabel->setText("Trying to connect to Alice" + addPoint());
    }

}

STCPWindow::~STCPWindow()
{
    delete ui;
}

void STCPWindow::on_start_button_clicked()
{
    if(state == OFF) {
        ui->messageLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
        ui->messageLabel->setText(host == "Alice" ? "Can't start without Bob" : "Can't start without Alice");
    } else if(state == CONNECTED) {
        ui->start_button->setEnabled(false);
        ui->messageLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
        ui->messageLabel->setText(host == "Alice" ? "Waiting for Bob...": "Waiting for Alice...");
        writeTcp(socket(), "Start");
        state = WAITING;
    } else {
        if(host == "Alice") {
            startAlice();
        } else {
            writeTcp(client->getSocket(), "StartA");
        }
    }
}

void STCPWindow::on_getInput_button_clicked()
{
    QFile file(QDir::currentPath() + "/input.txt");
    if(!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Error getting input";
    }

    QTextStream in(&file);
    QStringList inputs = in.readLine().split(",");

    QString input0, input1;

    input0 = inputs[0];
    if(inputs.size() < 2) {
        input1 = "0";
    } else {
        input1 = inputs[1];
    }

    if (input1.length() == 0)
        input0 = "0";
    if (input1.length() == 0)
        input1 = "0";

    ui->input0->setText(input0);
    ui->input1->setText(input1);

    file.close();
}

void STCPWindow::connectClient()
{
    if(host == "Alice") {
        if(state == OFF) {
            connect(server->getSocket(), SIGNAL(readyRead()), this, SLOT(socketMessage()));
            connect(server->getSocket(), SIGNAL(disconnected()), this, SLOT(otherDisconnected()));
            state = CONNECTED;
            qDebug() << "Bob is connected!";
            ui->socketLabel->setStyleSheet("color: rgb(138, 226, 52);" + defaultSocketStyle);
            ui->socketLabel->setText("Bob is connected!");
            ui->messageLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
            ui->messageLabel->setText("Start or wait for Bob!");
            writeTcp(server->getSocket(), "Available");
        } else {
            writeTcp(server->getSocket(), "Busy");
        }
    } else {
        qDebug() << "Trying to connect to Alice";
        ui->socketLabel->setText("Trying to connect to Alice" + addPoint());
        if(client->connect(tgIp, quint16(tgPort.toInt() + 1))) {
            connect(client->getSocket(), SIGNAL(readyRead()), this, SLOT(socketMessage()));
            connect(client->getSocket(), SIGNAL(disconnected()), this, SLOT(otherDisconnected()));
            timer->stop();
        } else {
            if(!timer->isActive())timer->start(1000);
        }
    }
}

void STCPWindow::otherDisconnected() {
    state = OFF;
    ui->socketLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
    ui->messageLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
    ui->start_button->setEnabled(true);
    if(host == "Bob") {
        connectClient();
        ui->messageLabel->setText("Alice disconnected!");
    } else {
        ui->socketLabel->setText("Waiting for Bob to connect!");
        ui->messageLabel->setText("Bob disconnected!");
    }
}

void STCPWindow::socketMessage()
{
    QString response = readTcp(socket());
    qDebug() << host + " " + state + " Receiving Message: " + response;
    // Happens when alice fails to retrieve the key
    if(response == "Fail") {
        state = CONNECTED;
        ui->messageLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
        ui->messageLabel->setText("Something failed with Alice!");
        ui->start_button->setEnabled(true);
    } else {
        switch (state) {
            case OFF:
                // Should only happen to the client, when in connects to Alice, it will receive available or busy
                if(response == "Available") {
                    state = CONNECTED;
                    qDebug() << "Connected to Alice";
                    ui->socketLabel->setStyleSheet("color: rgb(138, 226, 52);" + defaultSocketStyle);
                    ui->socketLabel->setText("Connected to Alice!");
                    ui->messageLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
                    ui->messageLabel->setText("Start or wait for Alice!");
                } else {
                    ui->socketLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
                    ui->socketLabel->setText(tgIp + ":" + tgPort + " is Busy!");
                    client->disconnect();
                }
                break;
            case CONNECTED:
                // Happens to both, it warns one host that the other wants to start computing a function
                if(response == "Start") {
                    ui->messageLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
                    state = WAITING;
                    QString tmp = host == "Alice" ? "Bob" : "Alice";
                    ui->messageLabel->setText(tmp +  " want's to compute the moda function.");
                }
                break;
            case WAITING:
                // When both hosts click start at exact same time or when alice starts computing it stends StartB or when bob wants to start it sends StartA
                if(response == "Start" && host == "Alice") {
                    startAlice();
                } else if(response == "StartB") {
                    startBob();
                } else if(response == "StartA") {
                    startAlice();
                }
                break;
            case OUTPUT:
                ui->start_button->setText("Start");
                ui->start_button->setEnabled(true);
                ui->output->setText(response);
                ui->messageLabel->setText("Function computed! Start or wait for Bob.");
                state = CONNECTED;
        }
    }
}

void STCPWindow::keyMessage()
{
    QString response = readTcp(keyClient->getSocket());
    keyClient->disconnect();
    qDebug() << host + " " + state + " Receiving message from Key host: " + response;
    QRegExp reg("\\d*");
    if (reg.exactMatch(response)) {
        ui->messageLabel->setStyleSheet("color: rgb(245, 121, 0);" + defaultSocketStyle);
        state = OUTPUT;
        writeTcp(server->getSocket(), "StartB");
        compute();
    } else {
        ui->messageLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
        ui->messageLabel->setText("Something failed while retrieving the key!");
        sendFail();
    }
    qDebug() << keyClient->getSocket()->state();
}

void STCPWindow::compute() {
    QStringList input_text = (ui->input0->text() + "," + ui->input1->text()).split(",");
    QString input = "";
    for(QString string : input_text) {
        for(int i = 0; i < 4 - string.length(); i++)
            input += "0";
        input += string;
    }

    QFile file(QDir::currentPath()+ "/" + host + ".sh");
    QString execution = "";
    if (file.open(QFile::ReadWrite|QFile::Truncate))
    {
        QTextStream stream(&file);
        execution += tgDir + "/bin/garbled_circuit/TinyGarble" + " --" + host.toLower() +
                                                    " --scd_file " + fDir + "/moda.scd" +
                                                    " -s " + tgIp +
                                                    " -p " + tgPort +
                                                    " --input " + input;
        stream << execution << endl;
        qInfo() << execution;
    }
    file.close();

    system("chmod +x " + host.toLocal8Bit() + ".sh");

    char line[500];
    std::FILE *script = popen("./" + host.toLocal8Bit() + ".sh", "r");
    while (fgets(line, sizeof(line), script) != NULL) {}
    pclose(script);

    bool ok = true;
    QString output;
    for(char c : line) {
        if(c == '\0')
            break;
        if(isdigit(c)) {
            output += c;
        } else if(isalpha(c)) {
            ok = false;
            break;
        }
    }

    if(ok && host == "Bob")
        ui->output->setText(output);
}

void STCPWindow::startAlice() {
    qDebug() << "Trying to connect to Key host";
    if(keyClient->connect(keyIp, quint16(keyPort.toInt()))) {
        connect(keyClient->getSocket(), SIGNAL(readyRead()), this, SLOT(keyMessage()));
        qDebug() << keyClient->getSocket()->state();
        writeTcp(keyClient->getSocket(), "50");
    } else {
        ui->messageLabel->setStyleSheet("color: rgb(204, 0, 0);" + defaultSocketStyle);
        ui->messageLabel->setText("Failed to connect to Key provider!");
        sendFail();
    }
}

void STCPWindow::startBob() {
    delay(25); // To avoid some situations where Bob was running TinyGarble first
    compute();
    ui->start_button->setText("Start");
    ui->start_button->setEnabled(true);
    state = CONNECTED;
    writeTcp(client->getSocket(), ui->output->text().toLocal8Bit().data());
    ui->messageLabel->setText("Function computed. Start or wait for Alice");
}

void STCPWindow::sendFail() {
    writeTcp(server->getSocket(), "Fail");
    ui->start_button->setEnabled(true);
    state = CONNECTED;
}

void STCPWindow::cancel() {

}

QTcpSocket* STCPWindow::socket() {
    return host == "Alice" ? server->getSocket() : client->getSocket();
}

QString STCPWindow::readTcp(QTcpSocket* socket)
{
    QString message = socket->readAll();
    return message;
}

void STCPWindow::writeTcp(QTcpSocket* socket, char* message)
{
    qDebug() << host << "Writing Message: " << message;
    socket->write(message, strlen(message));
    socket->flush();
}

QString STCPWindow::addPoint() {
    if(points == "...")
        points = ".";
     else
        points += ".";
    return points;
}
