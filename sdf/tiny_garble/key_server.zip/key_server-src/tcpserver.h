#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QObject>
#include <QDebug>
#include <QTcpServer>
#include <QTcpSocket>

class TcpServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit TcpServer(QObject *parent = nullptr);
    void closeServer();
    bool openServer(quint16 port);
    QTcpSocket* getSocket();


signals:

public slots:
    void newConnection();
    void getKey();
    void writeTcp(char *);
    QString readTcp();

private:
    QTcpSocket *socket;
    int nrConnections;
    QString currentKey = "";
};

#endif // TCPSERVER_H
