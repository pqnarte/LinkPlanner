/home/enamak/TinyGarble/bin/garbled_circuit/TinyGarble --bob --scd_file /home/enamak/circuits/moda/moda.scd -s 192.168.1.69 -p 1234 --input 00030013
