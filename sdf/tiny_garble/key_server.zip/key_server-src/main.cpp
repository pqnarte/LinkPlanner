#include <QCoreApplication>
#include "tcpserver.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    TcpServer *tcpServer = new TcpServer();
    tcpServer->openServer(3600);

    return a.exec();
}
