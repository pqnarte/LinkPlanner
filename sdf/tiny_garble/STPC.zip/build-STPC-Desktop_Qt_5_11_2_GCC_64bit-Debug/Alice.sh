/home/enamak/TinyGarble/bin/garbled_circuit/TinyGarble --alice --scd_file /home/enamak/circuits/scd/moda.scd -s 127.0.0.1 -p 1234 --input 00000000
