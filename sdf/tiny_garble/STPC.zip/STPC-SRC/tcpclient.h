#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QObject>
#include <QDebug>
#include <QTcpSocket>


class TcpClient : public QObject
{
    Q_OBJECT
public:
    explicit TcpClient(QObject *parent = nullptr);
    void disconnect();
    bool connect(QString, quint16);
    QTcpSocket* getSocket();

signals:

public slots:

private:
    QTcpSocket *socket;
    bool connected;
};

#endif // TCPCLIENT_H
