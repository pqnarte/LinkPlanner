#include <fstream>
#include<iostream>
using namespace std;

int main() {

	std::fstream f;
	f.open("keys.txt", std::fstream::in | std::fstream::out | std::fstream::app);
	while(1){
	}

}
