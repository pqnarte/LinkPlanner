#ifndef STCPWINDOW_H
#define STCPWINDOW_H

#include <QMainWindow>
#include "tcpserver.h"
#include "tcpclient.h"

#define OFF 0
#define CONNECTED 1
#define WAITING 2
#define OUTPUT 3

namespace Ui {
class STCPWindow;
}

class STCPWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit STCPWindow(QWidget *parent = nullptr, QString = nullptr, QPoint = QPoint(0,0), QString = nullptr, QString = nullptr, QString = nullptr, QString = nullptr, QString = nullptr, QString = nullptr);
    ~STCPWindow();

private slots:
    void connectClient();
    void socketMessage();
    void keyMessage();
    void otherDisconnected();
    void on_start_button_clicked();
    void on_getInput_button_clicked();

private:
    Ui::STCPWindow *ui;

    QString points;
    quint16 state;
    QTimer *timer;

    // Alice
    TcpServer *server;
    TcpClient *keyClient;

    // Bob
    TcpClient *client;

    QString host;
    QString tgDir;
    QString fDir;
    QString tgIp;
    QString tgPort;
    QString keyIp;
    QString keyPort;

    QString readTcp(QTcpSocket*);
    void writeTcp(QTcpSocket*, char*);
    QTcpSocket* socket();
    void compute();
    void startAlice();
    void startBob();
    void sendFail();
    void cancel();
    QString addPoint();

    QString defaultSocketStyle = "border: 0px solid black;";

};

#endif // STCPWINDOW_H
