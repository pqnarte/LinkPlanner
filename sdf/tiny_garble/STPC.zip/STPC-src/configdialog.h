#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>
#include <QAbstractButton>

namespace Ui {
class ConfigDialog;
}

class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(QWidget *parent = nullptr);
    ~ConfigDialog();
    QString getTgIp();
    QString getTgPort();
    QString getKeyIp();
    QString getKeyPort();
    int execute(QString = nullptr);
    void reload();

private slots:
    void on_buttonBox_2_accepted();
    void on_buttonBox_2_rejected();
    void on_tgPortInput_textEdited(const QString &arg1);
    void on_tgIpInput_textEdited(const QString &arg1);
    void on_keyIpInput_textEdited(const QString &arg1);
    void on_keyPortInput_textEdited(const QString &arg1);

private:
    Ui::ConfigDialog *ui;
    QString lastTgIp;
    bool validTgIp;
    bool validKeyIp;
    bool validTgPort;
    bool validKeyPort;
    bool isAlice;
};

#endif // CONFIGDIALOG_H
